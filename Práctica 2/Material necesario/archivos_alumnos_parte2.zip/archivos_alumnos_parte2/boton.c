/*********************************************************************************************
* Fichero:	button.c
* Autor:		
* Descrip:	Funciones de manejo de los pulsadores (EINT6-7)
* Version:	
*********************************************************************************************/

/*--- ficheros de cabecera ---*/
#include "44b.h"
#include "def.h"
/*--- variables globales ---*/
unsigned int update = 0;
unsigned int pausa = 0;
unsigned int resetsymbol=0;

/*--- declaracion de funciones ---*/
void Eint4567_ISR(void) __attribute__ ((interrupt ("IRQ"))); 
void Eint4567_init(void);

#define INTPND  (*(volatile unsigned *)0x01E00004)

/*--- codigo de funciones ---*/
void Eint4567_init(void)
{
/*TAREA 1a*/
	/* Configuracion del controlador de interrupciones */
	???		   // Borra INTPND   
	???		   // Borra EXTINTPND   
	???		   // Configura las linas como de tipo IRQ mediante rINTMOD
	???		   // Habilita int. vectorizadas y la linea IRQ (FIQ no) mediante rINTCON
	???		   // Emascara todas las lineas excepto eint4567 y el bit global mediante rINTMSK
		
	/* Establece la rutina de servicio para Eint4567 */
    pISR_EINT4567 = (int)Eint4567_ISR;
    
    /* Configuracion del puerto G */
    rPCONG  = 0xffff;        		// Establece la funcion de los pines (EINT0-7)
	rPUPG   = 0x0;                  // Habilita el "pull up" del puerto	    
	rEXTINT = rEXTINT|0x22222222;   // Configura las lineas de int. como de flanco de bajada	

    /* Por precaucion, se vuelven a borrar los bits de INTPND y EXTINTPND */
 	???		   // Borra INTPND   
	???		   // Borra EXTINTPND 
/*fin TAREA 1a*/  
}

void Eint4567_ISR(void)
{          
    int which_int;
	/*TAREA 1b*/
    /* Idenficiar la interrupcion */
     ....... 

    /* Codigo para eliminar rebotes*/
	......
	/* Reflejar en update el sentido de la actualizacion 
	   Nota: para solucionar los problemas de rebotes en el pulsador 
             solo se modifica update cuando se encuentra a cero */ 

       switch (which_int) {
      	case ??:
      		pausa= ! pausa;
         	update = 1; // actualizar al simbolo siguiente
         	break;
      	case 8:
      		resetsymbol=1;
      	 	update = 5; // actualizar al simbolo anterior
      	 	break;
      	default:
         	break;
       } 
    
    /* Finalizar ISR */    
    ???			// borra los bits en EXTINTPND		
    ??? 		// borra el bit pendiente en INTPND
	/*fin TAREA 1b*/	
}

