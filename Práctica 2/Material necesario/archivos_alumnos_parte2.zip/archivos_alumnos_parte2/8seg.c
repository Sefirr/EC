/*********************************************************************************************
* Fichero:	8led.c
* Autor:		
* Descrip:	Funciones de control del display 8-segmentos
* Version:	
*********************************************************************************************/

/*--- ficheros de cabecera ---*/
#include "44b.h"
#include "def.h"

/*--- definicion de macros ---*/
#define	LED8ADDR	(*(volatile unsigned char *)(0x2140000))

/* Mapa de bits de cada segmento 
  (valor que se debe escribir en el display para que se ilumine el segmento) */
#define SEGMENT_A		~0x80		
#define SEGMENT_B		~0x40
#define SEGMENT_C		~0x20
#define SEGMENT_D		~0x08
#define SEGMENT_E		~0x04
#define SEGMENT_F		~0x02
#define SEGMENT_G		~0x01
#define SEGMENT_P		~0x10

/*--- variables globales ---*/
/* tabla de segmentos */
int Symbol[] = { SEGMENT_A, SEGMENT_B, SEGMENT_C, SEGMENT_D, SEGMENT_E, SEGMENT_G,SEGMENT_F};
			  					  
/*--- declaraci�n de funciones ---*/
void D8Led_init(void);
void D8Led_symbol(int value); 

/*--- c�digo de las funciones ---*/
void D8Led_init(void)
{
    /* Estado inicial del display con todos los segmentos iluminados 
       (buscar en los ficheros de cabera la direccion implicada) */
    LED8ADDR = 0 ;
}

void D8Led_symbol(int value)
{
/*Tarea 3*/
	/* muestra el Symbol[value] en el display   */
 		LED8ADDR = ????? 
		
		
/*fin Tarea 3*/		
}
