#ifndef __LED_H
#define __LED_H

void switchLed1();
void switchLed2();
void init_leds();

#endif
