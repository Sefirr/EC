#ifndef BUTTON_H_
#define BUTTON_H_


void DoDetecta(void);

#endif /* BUTTON_H_ */
