#ifndef __keyboard_H__
#define __keyboard_H__

#define KEY_VALUE_MASK	0x0f


#endif /* __keyboard_H__ */
